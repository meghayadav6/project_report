/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author p c
 */
public class storeData {
    static int ID=0;
    public void storeID(int i){
        ID=i;
    }
    static String username = "";
    public void storeUsername(String u){
        username=u;
    }
    static String pop = "";
   public void storePop(String p){
        pop = p;
    }
}
